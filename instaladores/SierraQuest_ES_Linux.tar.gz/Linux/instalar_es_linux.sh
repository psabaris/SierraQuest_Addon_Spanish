#!/usr/bin/env bash
# =====================================================================
#  Sierra Quest — Instalador de la traducción al español (Linux)
# =====================================================================
#  Uso:   bash instalar_es_linux.sh                 (detecta el juego)
#         bash instalar_es_linux.sh "/ruta/al/juego"
#
#  Qué hace:
#   1. Ubica la carpeta de datos del juego (donde están el .ags, en-UK.tra
#      y acsetup.cfg; en las versiones de AGS para Linux suele ser data/).
#      También sirve para la versión de Windows bajo Wine/Proton
#      (carpeta con "Sierra Quest.exe").
#   2. Copia es.tra a esa carpeta.
#   3. Pone translation=es en [language] de:
#        - <carpeta de datos>/acsetup.cfg
#        - ${XDG_DATA_HOME:-~/.local/share}/ags/Sierra Quest/acsetup.cfg
#          (config de usuario de AGS 3.6, tiene prioridad)
# =====================================================================

set -u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TRA="$SCRIPT_DIR/es.tra"
XDG_DATA="${XDG_DATA_HOME:-$HOME/.local/share}"
USER_CFG="$XDG_DATA/ags/Sierra Quest/acsetup.cfg"

echo "=== Sierra Quest — Traducción al español (Linux) ==="
echo

if [[ ! -f "$TRA" ]]; then
    echo "Error: no se encontró es.tra junto a este script ($SCRIPT_DIR)."
    exit 1
fi

# ¿Es una carpeta de datos de AGS?
is_data_dir() {
    local d="$1"
    [[ -d "$d" ]] || return 1
    [[ -f "$d/en-UK.tra" ]] && return 0
    [[ -f "$d/Sierra Quest.exe" ]] && return 0
    compgen -G "$d/*.ags" >/dev/null && return 0
    [[ -f "$d/acsetup.cfg" && -f "$d/audio.vox" ]] && return 0
    return 1
}

# Dada una carpeta del juego, devuelve la carpeta de datos
resolve_data_dir() {
    local d="${1%/}" s
    for s in "$d" "$d/data" "$d/Data" "$d/game"; do
        if is_data_dir "$s"; then echo "$s"; return 0; fi
    done
    return 1
}

detect() {
    local c found
    local candidates=(
        "$HOME/Sierra Quest" "$HOME/SierraQuest"
        "$HOME/Games/Sierra Quest" "$HOME/games/Sierra Quest" "$HOME/Juegos/Sierra Quest"
        "$XDG_DATA/Steam/steamapps/common/Sierra Quest"
        "$HOME/.steam/steam/steamapps/common/Sierra Quest"
        "$HOME/.var/app/com.valvesoftware.Steam/.local/share/Steam/steamapps/common/Sierra Quest"
        "$HOME/GOG Games/Sierra Quest"
        "$HOME/.config/itch/apps/sierra-quest" "$HOME/.config/itch/apps/Sierra Quest"
        "/opt/Sierra Quest" "/opt/sierra-quest" "/usr/local/games/Sierra Quest" "/usr/games/Sierra Quest"
        "$SCRIPT_DIR" "$(dirname "$SCRIPT_DIR")"
    )
    for c in "${candidates[@]}"; do
        if found="$(resolve_data_dir "$c")"; then echo "$found"; return 0; fi
    done

    # Búsqueda: archivos o carpetas con "sierra" y "quest" en el nombre
    while IFS= read -r c; do
        [[ -d "$c" ]] || c="$(dirname "$c")"
        if found="$(resolve_data_dir "$c")"; then echo "$found"; return 0; fi
    done < <(find "$HOME" /opt /usr/games /usr/local/games -maxdepth 5 \
                -iname '*sierra*quest*' -not -path '*/.cache/*' -not -path '*/proc/*' 2>/dev/null)
    return 1
}

# set_ini <archivo> : deja translation=es dentro de [language]
set_ini() {
    local f="$1" sudo_cmd="${2:-}"
    local tmp
    tmp="$(mktemp)" || return 1
    if [[ -f "$f" ]]; then
        awk '
            BEGIN { insec = 0; done = 0 }
            { sub(/\r$/, "") }
            /^[ \t]*\[/ {
                if (insec && !done) { print "translation=es"; done = 1 }
                insec = (tolower($0) ~ /^[ \t]*\[language\][ \t]*$/)
                print; next
            }
            insec && tolower($0) ~ /^[ \t]*translation[ \t]*=/ {
                if (!done) { print "translation=es"; done = 1 }
                next
            }
            { print }
            END {
                if (!done) {
                    if (!insec) print "[language]"
                    print "translation=es"
                }
            }' "$f" > "$tmp" || { rm -f "$tmp"; return 1; }
    else
        printf '[language]\ntranslation=es\n' > "$tmp"
    fi
    $sudo_cmd mkdir -p "$(dirname "$f")" && $sudo_cmd cp "$tmp" "$f" && $sudo_cmd chmod 644 "$f"
    local rc=$?
    rm -f "$tmp"
    return $rc
}

# ------------------------------------------------------------------ main

DATA_DIR=""
if [[ $# -ge 1 && -n "$1" ]]; then
    DATA_DIR="$(resolve_data_dir "$1")" || DATA_DIR=""
    [[ -z "$DATA_DIR" ]] && echo "Aviso: '$1' no parece ser la carpeta de Sierra Quest."
else
    echo "Buscando Sierra Quest..."
    DATA_DIR="$(detect)" || DATA_DIR=""
fi

if [[ -n "$DATA_DIR" ]]; then
    echo "Juego encontrado en: $DATA_DIR"
    read -rp "¿Instalar la traducción ahí? [S/n] " ans
    case "${ans:-s}" in [nN]*) DATA_DIR="" ;; esac
fi

while [[ -z "$DATA_DIR" ]]; do
    read -rp "Ingresá la ruta de la carpeta del juego (o Enter para salir): " input
    [[ -z "$input" ]] && exit 1
    input="${input%\'}"; input="${input#\'}"; input="${input%\"}"; input="${input#\"}"
    input="${input/#\~/$HOME}"
    if DATA_DIR="$(resolve_data_dir "$input")"; then
        break
    elif [[ -d "$input" ]]; then
        read -rp "No parece la carpeta de Sierra Quest. ¿Instalar igual ahí? [s/N] " ans
        case "${ans:-n}" in [sS]*) DATA_DIR="${input%/}" ;; esac
    else
        echo "La carpeta no existe: $input"
    fi
done

SUDO=""
if [[ ! -w "$DATA_DIR" ]] || { [[ -e "$DATA_DIR/acsetup.cfg" ]] && [[ ! -w "$DATA_DIR/acsetup.cfg" ]]; }; then
    echo "La carpeta del juego requiere permisos de administrador."
    SUDO="sudo"
fi

if ! $SUDO cp "$TRA" "$DATA_DIR/es.tra"; then
    echo "Error: no se pudo copiar es.tra a $DATA_DIR"
    exit 1
fi
echo "[OK] es.tra copiado a $DATA_DIR"

if set_ini "$DATA_DIR/acsetup.cfg" "$SUDO"; then
    echo "[OK] $DATA_DIR/acsetup.cfg"
else
    echo "Aviso: no se pudo actualizar $DATA_DIR/acsetup.cfg"
fi

if set_ini "$USER_CFG"; then
    echo "[OK] $USER_CFG"
else
    echo "Error: no se pudo actualizar $USER_CFG"
    exit 1
fi

echo
echo "¡Listo! Iniciá Sierra Quest y el juego va a estar en español."
