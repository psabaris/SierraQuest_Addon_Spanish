#!/bin/bash
# =====================================================================
#  Sierra Quest — Instalador de la traducción al español (macOS)
# =====================================================================
#  Uso desde Terminal (no requiere aprobar nada en Gatekeeper):
#      bash instalar_es_mac.sh                 # detecta el juego y pregunta
#      bash instalar_es_mac.sh "/ruta/Sierra Quest.app"
#
#  Modos internos usados por SierraQuest_Instalador_ES.app:
#      --detect              imprime la ruta del juego detectado
#      --check  <app>        exit 0 si <app> es Sierra Quest
#      --patch-app <app>     copia es.tra al bundle y lo re-firma
#      --set-config          activa translation=es en la config de usuario
#      --uninstall <app>     quita es.tra y vuelve al idioma original
#
#  Por qué se re-firma el juego:
#    El juego está firmado y notarizado. AGS sólo busca los .tra en
#    Contents/Resources, así que hay que agregar es.tra dentro del bundle,
#    lo que invalida el sello de la firma y macOS deja de abrir el juego.
#    Re-firmarlo de forma local (ad-hoc) y quitarle la cuarentena lo
#    soluciona. Probado con AGS 3.6.2 en macOS 27.
#
#  Códigos de salida de --patch-app:
#      10  macOS bloqueó la modificación (permiso "Gestión de apps")
#      11  sin permisos de escritura (hace falta contraseña de admin)
#      12  no se encontró es.tra
#      13  no se pudo re-firmar el juego
# =====================================================================

set -u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUNDLE_ID="studio.pointandclick.sierraquest"
USER_CFG="$HOME/Library/Application Support/Sierra Quest/acsetup.cfg"

find_tra() {
    local f
    for f in "$SCRIPT_DIR/es.tra" "$SCRIPT_DIR/../Resources/es.tra"; do
        if [ -f "$f" ]; then echo "$f"; return 0; fi
    done
    return 1
}

is_game_app() {
    local app="${1%/}"
    [ -d "$app/Contents/Resources" ] || return 1
    [ -d "$app/Contents/MacOS" ] || return 1
    case "$app" in */AppTranslocation/*) return 1 ;; esac
    if [ -f "$app/Contents/Info.plist" ] &&
       grep -q "$BUNDLE_ID" "$app/Contents/Info.plist" 2>/dev/null; then
        return 0
    fi
    # Otras ediciones (p. ej. Steam): bundle AGS con el nombre del juego
    if [ -f "$app/Contents/Resources/acsetup.cfg" ] &&
       ls "$app/Contents/Resources/"*.ags >/dev/null 2>&1; then
        case "$(basename "$app")" in *[Ss]ierra*[Qq]uest*) return 0 ;; esac
    fi
    return 1
}

detect() {
    local c
    for c in \
        "/Applications/Sierra Quest.app" \
        "$HOME/Applications/Sierra Quest.app" \
        "/Applications/Games/Sierra Quest.app" \
        "$HOME/Library/Application Support/Steam/steamapps/common/Sierra Quest/Sierra Quest.app"
    do
        if is_game_app "$c"; then echo "$c"; return 0; fi
    done
    while IFS= read -r c; do
        [ -n "$c" ] || continue
        if is_game_app "$c"; then echo "$c"; return 0; fi
    done < <( { mdfind "kMDItemCFBundleIdentifier == '$BUNDLE_ID'"
                mdfind "kMDItemFSName == 'Sierra Quest.app'"; } 2>/dev/null )
    return 1
}

patch_app() {
    local app="${1%/}" tra out
    tra="$(find_tra)" || { echo "No se encontró es.tra junto al instalador." >&2; return 12; }

    if ! out="$(cp "$tra" "$app/Contents/Resources/es.tra" 2>&1)"; then
        case "$out" in
            *"Operation not permitted"*) return 10 ;;
            *"Permission denied"*)       return 11 ;;
            *) echo "$out" >&2; return 11 ;;
        esac
    fi

    resign "$app"
}

resign() {
    local app="$1"
    chmod -R u+w "$app" 2>/dev/null
    xattr -cr "$app" 2>/dev/null
    if ! /usr/bin/codesign --force --deep --sign - "$app" >/dev/null 2>&1 ||
       ! /usr/bin/codesign --verify --deep --strict "$app" >/dev/null 2>&1; then
        echo "No se pudo re-firmar $app" >&2
        return 13
    fi
    return 0
}

# set_ini <archivo> <valor>: deja translation=<valor> dentro de [language]
set_ini() {
    local f="$1" val="$2"
    mkdir -p "$(dirname "$f")" || return 1
    if [ ! -f "$f" ]; then
        printf '[language]\ntranslation=%s\n' "$val" > "$f"
        return $?
    fi
    awk -v val="$val" '
        BEGIN { insec = 0; done = 0 }
        { sub(/\r$/, "") }
        /^[ \t]*\[/ {
            if (insec && !done) { print "translation=" val; done = 1 }
            insec = ($0 ~ /^[ \t]*\[language\][ \t]*$/)
            print; next
        }
        insec && /^[ \t]*translation[ \t]*=/ {
            if (!done) { print "translation=" val; done = 1 }
            next
        }
        { print }
        END {
            if (!done) {
                if (!insec) print "[language]"
                print "translation=" val
            }
        }' "$f" > "$f.tmp.$$" && mv "$f.tmp.$$" "$f"
}

uninstall() {
    local app="${1%/}"
    rm -f "$app/Contents/Resources/es.tra" || return 11
    resign "$app" || return $?
    [ -f "$USER_CFG" ] && set_ini "$USER_CFG" ""
    return 0
}

interactive() {
    local app="${1:-}" ans rc
    echo "=== Sierra Quest — Traducción al español (macOS) ==="
    echo
    find_tra >/dev/null || { echo "Error: no se encontró es.tra junto a este script."; exit 1; }

    if [ -z "$app" ]; then
        if app="$(detect)"; then
            echo "Juego encontrado en: $app"
        else
            echo "No se encontró Sierra Quest automáticamente."
            echo "Arrastrá 'Sierra Quest.app' a esta ventana y presioná Enter:"
            read -r app
            app="${app%\"}"; app="${app#\"}"; app="${app%\'}"; app="${app#\'}"
            app="${app%% }"; app="${app//\\ / }"
        fi
    fi
    app="${app%/}"
    if ! is_game_app "$app"; then
        echo "Error: '$app' no parece ser Sierra Quest.app"
        exit 1
    fi

    patch_app "$app"; rc=$?
    if [ $rc -eq 11 ]; then
        echo "Hace falta permiso de administrador para modificar el juego."
        sudo /bin/bash "$0" --patch-app "$app"; rc=$?
    fi
    case $rc in
        0) ;;
        10) echo
            echo "macOS bloqueó la modificación del juego."
            echo "Abrí Configuración del Sistema → Privacidad y seguridad → Gestión de apps,"
            echo "activá 'Terminal' y volvé a ejecutar este script."
            open "x-apple.systempreferences:com.apple.preference.security?Privacy_AppBundles" 2>/dev/null
            exit 1 ;;
        *)  echo "Error durante la instalación (código $rc)."; exit 1 ;;
    esac

    set_ini "$USER_CFG" "es" || { echo "Error: no se pudo escribir $USER_CFG"; exit 1; }
    echo "[OK] es.tra instalado en $app/Contents/Resources"
    echo "[OK] Idioma activado en $USER_CFG"
    echo
    echo "¡Listo! Abrí Sierra Quest y el juego va a estar en español."
}

case "${1:-}" in
    --detect)     detect ;;
    --check)      is_game_app "${2:-}" ;;
    --patch-app)  patch_app "${2:-}" ;;
    --set-config) set_ini "$USER_CFG" "es" ;;
    --uninstall)  uninstall "${2:-}" ;;
    *)            interactive "${1:-}" ;;
esac
